const {Shop, Item} = require("../src/gilded_rose");

describe("Gilded Rose", function() {
  it("should foo", function() {
    const gildedRose = new Shop([new Item("foo", 0, 0)]);
    const items = gildedRose.updateQuality();
    expect(items[0].name).toBe("foo");
  });

  it("quality can not be more than 50", function() {
    const gildedRose = new Shop([new Item("item with 51", 0, 51)]);
    const items = gildedRose.updateQuality();
    expect(items[0].quality).toBeLessThan(51);
  });

  it("sulfaras quality should not change", function() {
    const gildedRose = new Shop([new Item("Sulfuras, Hand of Ragnaros", 0, 50)]);
    const items = gildedRose.updateQuality();
    expect(items[0].quality).toEqual(50);
  });

  it("Backstage quality increase", function() {
    const gildedRose = new Shop([new Item("Backstage passes to a TAFKAL80ETC concert", 0, 49)]);
    const items = gildedRose.updateQuality();
    expect(items[0].quality).toEqual(50);
  });
});
