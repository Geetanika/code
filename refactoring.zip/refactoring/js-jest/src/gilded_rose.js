class Item {
  constructor(name, sellIn, quality){
    this.name = name;
    this.sellIn = sellIn;
    this.quality = quality;
  }
}

class Shop {
  constructor(items=[]){
    this.items = items;
  }
  updateQuality() {
    for (let i = 0; i < this.items.length; i++) {
      const currItem = this.items[i];
      const {name, quality, sellIn} = currItem;

      if (name != 'Aged Brie' 
      && name != 'Backstage passes to a TAFKAL80ETC concert'
      && quality > 0
      && name != 'Sulfuras, Hand of Ragnaros') {
        currItem.quality = quality - 1;
      } else {
        if (quality < 50) {
          currItem.quality = quality + 1;
          if (name == 'Backstage passes to a TAFKAL80ETC concert') {
            if ((sellIn < 11 || sellIn < 6)  && quality < 50) {
              currItem.quality = quality + 1;
            }
          }
        }
      }
      if (name != 'Sulfuras, Hand of Ragnaros') {
        currItem.sellIn = sellIn - 1;
      }
      if (sellIn < 0) {
        if (name != 'Aged Brie') {
          if (name != 'Backstage passes to a TAFKAL80ETC concert'
              && quality > 0 && name != 'Sulfuras, Hand of Ragnaros') {
              currItem.quality = quality - 1;
          } else {
            currItem.quality = currItem.quality - currItem.quality;
          }
        } else {
          if (quality < 50) {
            currItem.quality = quality + 1;
          }
        }
      }
    }

    return this.items;
  }
}

module.exports = {
  Item,
  Shop
}
