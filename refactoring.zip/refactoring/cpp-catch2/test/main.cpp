#define CATCH_CONFIG_MAIN
#define APPROVALS_CATCH

#include "catch2/catch.hpp"
#include "ApprovalTests.hpp"