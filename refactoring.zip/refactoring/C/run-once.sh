make
./GildedRoseTextTests
