## Build and test using any of the following

Command line:
- `swift test`

Xcode:
- Open this "swift" folder to open package
- In the Xcode menu, select Product > Test to run tests

AppCode:
- Open this "swift" folder to open package
- Select "GildedRoseTests" configuration and run
