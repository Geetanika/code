# Gilded Rose (elm)

To run tests, enter `elm-test`

### Installing `elm-test` 

https://github.com/elm-explorations/test
