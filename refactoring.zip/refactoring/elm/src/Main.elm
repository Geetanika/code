module Main exposing (main)

import Html exposing (..)


main =
    text "Gilded Rose"
